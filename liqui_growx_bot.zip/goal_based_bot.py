# AI Trading Bot - LIQUI-GROWX
print('Bot started')
